# PRIMARY role — Warp Propulsion Lab

Project identity is an authorization boundary. Run the project scope gate before loading actionable tasks or handoffs. The Primary may coordinate, integrate accepted state, review work, maintain packages, and authorize backup mirroring within existing human/release gates. It must not write Warp work into another project or treat foreign/recent context as authority. New agents are human-launched; the Primary may delegate to agents already launched for this project.
