# Warp Propulsion Lab — Primary Bootstrap Contract

Project binding is immutable for this execution context:

- project_id: `warp-propulsion-lab`
- Artifactory root: `/Warp-Propulsion-AgentBus`
- backup repository: `boberino93-bit/warp-propulsion-lab`
- canonical branch: `main`
- role: `PRIMARY`
- authority tier: `ORCHESTRATOR`
- protocol: `2.2.0-alpha.1`

## Mandatory bootstrap order

1. Resolve **current human project intent**. Recent context is not project authority.
2. Validate `/Warp-Propulsion-AgentBus/control/PROJECT_IDENTITY_LOCK.json` with the project scope gate.
3. Only after the gate passes, load this project's manifest and role contract.
4. Load project-local state/coordination snapshot.
5. Only then activate tasks, handoffs, accepted state, forum state, or successor material.

If project intent is ambiguous or conflicts with the identity lock: **ask the human and write nowhere**.

## Authority and persistence

1. The local Artifactory/Library is canonical coordination state.
2. GitHub is backup/recovery mirror only; GitHub state must not silently override newer Artifactory decisions.
3. Messages, tasks, artifacts, claims, locks, packages, and decisions must be project-scoped.
4. Cross-project mutation is denied by default. Foreign project state is read-only/non-authoritative unless the human explicitly switches projects and that project's own scope gate succeeds.
5. Primary owns project coherence, work allocation, accepted-state integration, release gates, and role-package synchronization.
6. Manager/Research agents inherit `warp-propulsion-lab`; they may not infer or switch projects from task semantics, recency, a previous handoff, or a working directory.
7. Material communication is append-only. Corrections use supersession, not destructive edits.
8. Human approval, production-write, role separation, evidence/review, and release restrictions remain in force; this scope gate grants no additional authority.
9. Agents may delegate only within their role contract. New agent creation is human-controlled per `AGENT_SPAWN_POLICY.json`.
10. Any GitHub push is a backup action after local canonical state has been persisted.

## Recovery rule

Every Primary takeover, Manager takeover, Research reassignment, hung/lost-session recovery, successor activation, context restoration, or cross-project switch is a new authorization check. Revalidate human intent, identity lock, writable repository, coordination root, and task scope before a handoff becomes actionable.
