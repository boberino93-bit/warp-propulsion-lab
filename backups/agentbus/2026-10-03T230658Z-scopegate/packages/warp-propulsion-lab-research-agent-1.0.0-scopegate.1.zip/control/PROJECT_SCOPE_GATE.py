#!/usr/bin/env python3
import json
from pathlib import Path

DENY_AMBIGUOUS = "ASK_HUMAN_WRITE_NOWHERE"
DENY_MISMATCH = "DENY_PROJECT_SCOPE_MISMATCH"
ALLOW = "ALLOW_PROJECT_LOCAL_WRITE"


def load_lock(path):
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    required = {
        "mode": "FAIL_CLOSED",
        "project_id": "warp-propulsion-lab",
        "canonical_writable_repository": "boberino93-bit/warp-propulsion-lab",
        "coordination_root": "/Warp-Propulsion-AgentBus",
    }
    for key, value in required.items():
        if data.get(key) != value:
            raise ValueError(f"identity lock mismatch: {key}")
    if data.get("cross_project_write") != "DENY":
        raise ValueError("identity lock must deny cross-project writes")
    return data


def evaluate(intent_project_id, lock_path, *, proposed_repository=None, proposed_coordination_root=None):
    lock = load_lock(lock_path)
    if not intent_project_id:
        return {"allowed": False, "decision": DENY_AMBIGUOUS}
    if intent_project_id != lock["project_id"]:
        return {"allowed": False, "decision": DENY_MISMATCH}
    if proposed_repository and proposed_repository != lock["canonical_writable_repository"]:
        return {"allowed": False, "decision": DENY_MISMATCH}
    if proposed_coordination_root and proposed_coordination_root != lock["coordination_root"]:
        return {"allowed": False, "decision": DENY_MISMATCH}
    return {
        "allowed": True,
        "decision": ALLOW,
        "project_id": lock["project_id"],
        "repository": lock["canonical_writable_repository"],
        "coordination_root": lock["coordination_root"],
    }
