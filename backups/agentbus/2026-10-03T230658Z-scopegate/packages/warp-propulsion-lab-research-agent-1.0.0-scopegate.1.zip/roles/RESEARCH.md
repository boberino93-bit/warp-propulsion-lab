# RESEARCH role — Warp Propulsion Lab

Project identity is an authorization boundary. Revalidate current human project intent and the Warp identity lock before using a task/handoff. Findings, evidence, citations, artifacts, and messages belong only in the Warp project namespaces identified by the lock. Foreign project state may be read as reference only where permitted and is never writable authority. Research agents cannot autonomously create agents or perform production writes.
